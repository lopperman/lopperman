#!/bin/bash
# =============================================================================
# NetBox Webhook Test Script
# File: test_netbox_webhook.sh
#
# Usage: ./test_netbox_webhook.sh <EVENT_STREAM_URL> <TOKEN> [DEVICE_NAME] [EVENT_TYPE]
#
# Examples:
#   ./test_netbox_webhook.sh https://eda.example.com/api/eda/v1/external_event_stream/netbox-webhook-es/ mytoken123
#   ./test_netbox_webhook.sh https://eda.example.com/api/eda/v1/external_event_stream/netbox-webhook-es/ mytoken123 switch01 updated
# =============================================================================

set -e

# Arguments
EVENT_STREAM_URL="${1:-}"
TOKEN="${2:-}"
DEVICE_NAME="${3:-test-device-001}"
EVENT_TYPE="${4:-updated}"  # created, updated, deleted

# Validate required arguments
if [[ -z "$EVENT_STREAM_URL" || -z "$TOKEN" ]]; then
    echo "Usage: $0 <EVENT_STREAM_URL> <TOKEN> [DEVICE_NAME] [EVENT_TYPE]"
    echo ""
    echo "Arguments:"
    echo "  EVENT_STREAM_URL  - Full URL to your EDA event stream endpoint"
    echo "  TOKEN             - Authentication token for the event stream"
    echo "  DEVICE_NAME       - (Optional) Device name to simulate (default: test-device-001)"
    echo "  EVENT_TYPE        - (Optional) Event type: created|updated|deleted (default: updated)"
    echo ""
    echo "Example:"
    echo "  $0 https://eda.example.com/api/eda/v1/external_event_stream/netbox-webhook-es/ abc123 router01 created"
    exit 1
fi

# Generate timestamp
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%S.000000+00:00")
REQUEST_ID=$(uuidgen 2>/dev/null || cat /proc/sys/kernel/random/uuid 2>/dev/null || echo "test-$(date +%s)")

# Build NetBox-style webhook payload
PAYLOAD=$(cat <<EOF
{
  "event": "${EVENT_TYPE}",
  "timestamp": "${TIMESTAMP}",
  "model": "device",
  "username": "eda-test-user",
  "request_id": "${REQUEST_ID}",
  "data": {
    "id": 12345,
    "url": "https://netbox.example.com/api/dcim/devices/12345/",
    "display": "${DEVICE_NAME}",
    "name": "${DEVICE_NAME}",
    "device_type": {
      "id": 1,
      "url": "https://netbox.example.com/api/dcim/device-types/1/",
      "manufacturer": {
        "id": 1,
        "name": "Cisco"
      },
      "model": "Catalyst 9300"
    },
    "role": {
      "id": 1,
      "name": "Access Switch"
    },
    "tenant": null,
    "platform": {
      "id": 1,
      "name": "cisco_ios"
    },
    "serial": "FCW12345678",
    "asset_tag": null,
    "site": {
      "id": 1,
      "name": "Site-A",
      "slug": "site-a"
    },
    "location": null,
    "rack": null,
    "position": null,
    "face": null,
    "latitude": null,
    "longitude": null,
    "parent_device": null,
    "status": {
      "value": "active",
      "label": "Active"
    },
    "airflow": null,
    "primary_ip": {
      "id": 100,
      "address": "192.168.1.100/24"
    },
    "primary_ip4": {
      "id": 100,
      "address": "192.168.1.100/24"
    },
    "primary_ip6": null,
    "oob_ip": null,
    "cluster": null,
    "virtual_chassis": null,
    "vc_position": null,
    "vc_priority": null,
    "description": "Test device for EDA POC",
    "comments": "",
    "config_template": null,
    "local_context_data": null,
    "tags": [],
    "custom_fields": {},
    "created": "2024-01-01T00:00:00.000000Z",
    "last_updated": "${TIMESTAMP}"
  },
  "snapshots": {
    "prechange": {
      "status": "planned"
    },
    "postchange": {
      "status": "active"
    }
  }
}
EOF
)

echo "=============================================="
echo "Sending NetBox Webhook Test Event"
echo "=============================================="
echo "Target URL: ${EVENT_STREAM_URL}"
echo "Device Name: ${DEVICE_NAME}"
echo "Event Type: ${EVENT_TYPE}"
echo "Timestamp: ${TIMESTAMP}"
echo "=============================================="
echo ""
echo "Payload:"
echo "${PAYLOAD}" | python3 -m json.tool 2>/dev/null || echo "${PAYLOAD}"
echo ""
echo "=============================================="
echo "Sending request..."
echo ""

# Send the request
HTTP_RESPONSE=$(curl -s -w "\n%{http_code}" \
    -X POST "${EVENT_STREAM_URL}" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${TOKEN}" \
    -d "${PAYLOAD}")

# Parse response
HTTP_BODY=$(echo "$HTTP_RESPONSE" | sed '$d')
HTTP_STATUS=$(echo "$HTTP_RESPONSE" | tail -n1)

echo "Response Status: ${HTTP_STATUS}"
echo "Response Body: ${HTTP_BODY}"
echo ""

if [[ "$HTTP_STATUS" -ge 200 && "$HTTP_STATUS" -lt 300 ]]; then
    echo "✅ SUCCESS - Event sent successfully!"
else
    echo "❌ FAILED - HTTP ${HTTP_STATUS}"
    echo "Check:"
    echo "  1. Event stream URL is correct"
    echo "  2. Token is valid"
    echo "  3. Rulebook activation is running"
fi
