# NetBox EDA → ISE Integration POC

## Quick Reference

### Files Included
| File | Purpose | Location in AAP |
|------|---------|-----------------|
| `eda_rb1.yml` | EDA Rulebook | EDA Project: `gienetauto-eda` (in `/extensions/eda/rulebooks/`) |
| `netbox_eda_pb1.yml` | Ansible Playbook | Controller Project: `gienetauto-lcm-ansible` |
| `test_netbox_webhook.sh` | Test script | Run from any Linux machine |

---

## Setup Checklist

### 1. Automation Controller - Job Template Setup

**CRITICAL**: The job template must be launchable WITHOUT any prompts.

```
Job Template: gienetauto-lcm-eda-netbox-poc
├── Name: gienetauto-lcm-eda-netbox-poc
├── Organization: GNSAUTO
├── Project: gienetauto-lcm-ansible
├── Playbook: netbox_eda_pb1.yml
├── Inventory: [SELECT YOUR INVENTORY - NOT "Ask on Launch"]
├── Execution Environment: ansible-2.18
├── Instance Groups: gnsauto-ig
│
├── Credentials:
│   └── [Attach any required credentials]
│
├── Variables (Extra Vars):
│   ise_base_url: "https://your-ise-server:9060"
│   ise_user_name: "your-ers-api-user"
│   ise_password: "your-ers-api-password"
│
└── Options:
    ├── [✓] Prompt on Launch: Extra Variables  ← MUST BE CHECKED!
    ├── [ ] Prompt on Launch: Inventory        ← MUST BE UNCHECKED
    ├── [ ] Prompt on Launch: Credentials      ← MUST BE UNCHECKED
    └── [ ] Prompt on Launch: Limit            ← MUST BE UNCHECKED
```

**Why "Prompt on Launch: Extra Variables" must be checked:**
- EDA passes `hostname`, `netbox_event_type`, and `netbox_device_status` via `job_args.extra_vars`
- If this is unchecked, EDA's extra_vars are silently dropped!

### 2. EDA Controller Setup

#### 2a. Verify Controller Token
```
Location: Settings → Controller Credentials (or AAP Gateway)
Required: Token with WRITE scope for the EDA service account user
```

#### 2b. Verify Project
```
Project: gienetauto-eda
├── Repository contains: /extensions/eda/rulebooks/eda_rb1.yml
└── Sync Status: Successful
```

#### 2c. Create/Update Rulebook Activation
```
Rulebook Activation: netbox-eda-test-rb
├── Organization: GNSAUTO
├── Project: gienetauto-eda
├── Rulebook: eda_rb1.yml
├── Event Streams: netbox-webhook-es
├── Decision Environment: de-supported-gnsauto
├── Log Level: Debug  ← SET TO DEBUG FOR TESTING
├── Restart Policy: On failure
└── Enabled: Yes
```

### 3. Validation Steps

#### Step 1: Verify Job Template Runs Standalone
```bash
# In Automation Controller UI:
# 1. Go to Templates → gienetauto-lcm-eda-netbox-poc
# 2. Click "Launch"
# 3. In the prompt, add this YAML:
hostname: "test-device-manual"
netbox_event_type: "manual-test"
netbox_device_status: "active"
# 4. Click Launch
# 5. Verify job completes successfully
```

#### Step 2: Verify Rulebook Activation Starts
```bash
# In EDA Controller UI:
# 1. Go to Rulebook Activations → netbox-eda-test-rb
# 2. Check Status = "Running" (not "Failed" or "Pending")
# 3. Check History tab for any errors
```

#### Step 3: Send Test Event
```bash
# Get your event stream URL and token from EDA Controller
# Event Streams → netbox-webhook-es → copy the URL and token

chmod +x test_netbox_webhook.sh
./test_netbox_webhook.sh \
    "https://your-eda-host/api/eda/v1/external_event_stream/netbox-webhook-es/" \
    "your-event-stream-token" \
    "test-switch-001" \
    "updated"
```

#### Step 4: Check Results
```bash
# In EDA Controller:
# 1. Rulebook Activations → netbox-eda-test-rb → History
#    - Should see the event received
#    - Should see debug messages printed
#
# 2. Rule Audit
#    - Should see the rule triggered
#    - Should see run_job_template action
#
# In Automation Controller:
# 1. Jobs
#    - Should see a new job for gienetauto-lcm-eda-netbox-poc
#    - Check job output for ISE response
```

---

## Troubleshooting

### Rulebook Activation Won't Start (Status: Failed)

| Symptom | Likely Cause | Fix |
|---------|--------------|-----|
| Fails immediately | Job template validation failed | Check job template has inventory set |
| "does not accept extra vars" | Prompt on Launch not enabled | Enable "Prompt on Launch: Extra Variables" |
| Authentication error | Token invalid/expired | Regenerate Controller token |
| Connection refused | Wrong Controller URL | Verify EDA→Controller connectivity |

### Rulebook Starts But Job Doesn't Trigger

| Symptom | Likely Cause | Fix |
|---------|--------------|-----|
| No rule audit entry | Condition not matching | Check event payload structure |
| Rule fires, no job | Organization name wrong | Verify organization is exactly "GNSAUTO" |
| Job template not found | Name mismatch | Verify job template name matches exactly |

### Job Runs But Fails

| Symptom | Likely Cause | Fix |
|---------|--------------|-----|
| "UNDEFINED_HOSTNAME" | extra_vars not passed | Enable "Prompt on Launch: Extra Variables" |
| ISE connection failed | Network/credentials | Test ISE API manually first |
| SSL certificate error | Self-signed cert | Set `validate_certs: false` (done in playbook) |

---

## Event Stream Token vs Controller Token

These are **different tokens** - don't confuse them:

| Token | Purpose | Where to Get |
|-------|---------|--------------|
| Event Stream Token | Authenticate incoming webhooks to EDA | EDA → Event Streams → your stream |
| Controller Token | EDA authenticates to run job templates | Controller → Users → Tokens |

---

## Expected Flow

```
NetBox Webhook                    EDA Controller                 Automation Controller
     │                                  │                                  │
     │ POST /event_stream/              │                                  │
     │ (device status change)           │                                  │
     │─────────────────────────────────>│                                  │
     │                                  │                                  │
     │                                  │ Rulebook processes event         │
     │                                  │ Debug msg: "Event Received"      │
     │                                  │                                  │
     │                                  │ run_job_template                 │
     │                                  │ (hostname from event.payload)    │
     │                                  │─────────────────────────────────>│
     │                                  │                                  │
     │                                  │                                  │ Launches job
     │                                  │                                  │ Runs playbook
     │                                  │                                  │ Calls ISE API
     │                                  │                                  │ Returns results
     │                                  │                                  │
```

---

## Quick Commands

```bash
# Check if rulebook activation pod is running (if on OpenShift)
oc get pods -n <eda-namespace> | grep activation

# Check activation logs (OpenShift)
oc logs -f <activation-pod-name> -n <eda-namespace>

# Test ISE API directly (verify credentials work)
curl -k -u "ise_user:ise_password" \
    -H "Accept: application/json" \
    "https://your-ise:9060/ers/config/networkdevice/name/test-device"

# Check EDA→Controller connectivity
curl -k -H "Authorization: Bearer <controller-token>" \
    "https://your-controller/api/v2/job_templates/"
```

---

## File Placement

Your git repository structure should look like:

```
gienetauto-lcm-ansible/          (Controller Project)
├── netbox_eda_pb1.yml           ← Playbook goes here
└── ...

gienetauto-eda/                  (EDA Project)
└── extensions/
    └── eda/
        └── rulebooks/
            └── eda_rb1.yml      ← Rulebook goes here
```

After adding files, sync both projects in their respective UIs.
